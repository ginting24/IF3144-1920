# Praktikum Database Manajement System :custard:
Review konsep Database manajement system dengan Praktik

- Praktikum 1: [Tunning](tunning/README.md)
